export class Login {
	constructor(
		public id?: string,
		public ttl?: number,
		public created?: string,
		public userId?: number) {}
}