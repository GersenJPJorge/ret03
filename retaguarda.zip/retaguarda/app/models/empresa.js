"use strict";
class Empresa {
    constructor(id, codEmpresa, nomeEmpresa, cnpjEmpresa, dataInclusaoEmpresa, dataUltimaAlteracaoEmpresa) {
        this.id = id;
        this.codEmpresa = codEmpresa;
        this.nomeEmpresa = nomeEmpresa;
        this.cnpjEmpresa = cnpjEmpresa;
        this.dataInclusaoEmpresa = dataInclusaoEmpresa;
        this.dataUltimaAlteracaoEmpresa = dataUltimaAlteracaoEmpresa;
    }
}
exports.Empresa = Empresa;
//# sourceMappingURL=empresa.js.map