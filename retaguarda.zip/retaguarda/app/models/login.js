"use strict";
class Login {
    constructor(id, ttl, created, userId) {
        this.id = id;
        this.ttl = ttl;
        this.created = created;
        this.userId = userId;
    }
}
exports.Login = Login;
//# sourceMappingURL=login.js.map