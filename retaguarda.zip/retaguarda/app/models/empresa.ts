export class Empresa {
	constructor(
		public id?: number,
		public codEmpresa?: number,
		public nomeEmpresa?: string,
		public cnpjEmpresa?: number,
		public dataInclusaoEmpresa?: string,
		public dataUltimaAlteracaoEmpresa?: string) {}
	}