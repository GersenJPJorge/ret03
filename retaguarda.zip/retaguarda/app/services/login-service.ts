import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Login } from '../models/login';
import { HttpUtilService } from './http-util-service';
import {Md5} from 'ts-md5/dist/md5';

@Injectable()
export class LoginService {

	private loginUrl:string = 'http://172.18.164.6:9082/esb-orbitall/oauth/token';
	private logoutUrl:string = '';

	constructor(private http: Http, private httpUtil: HttpUtilService) {
	}

	logar(usuario:string, senha:string): Observable<Login> {
	const passwordAsMd5 = Md5.hashStr(senha);

		let params = JSON.stringify(
			{ "grant_type" : 'password', "username": usuario, "password": passwordAsMd5 });

		return this.http.post(this.httpUtil.url(this.loginUrl), params, 
						this.httpUtil.headers())
	                .map(this.httpUtil.extrairDados)
	                .catch(this.httpUtil.processarErros);
	}

	sair() {
		delete localStorage['token'];
	}

	logado() {
		return localStorage['token'];
	}
}