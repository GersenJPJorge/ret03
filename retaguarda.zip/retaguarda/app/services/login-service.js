"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const core_1 = require('@angular/core');
const http_1 = require('@angular/http');
const http_util_service_1 = require('./http-util-service');
const md5_1 = require('ts-md5/dist/md5');
let LoginService = class LoginService {
    constructor(http, httpUtil) {
        this.http = http;
        this.httpUtil = httpUtil;
        this.loginUrl = 'http://172.18.164.6:9082/esb-orbitall/oauth/token';
        this.logoutUrl = '';
    }
    logar(usuario, senha) {
        const passwordAsMd5 = md5_1.Md5.hashStr(senha);
        let params = JSON.stringify({ "grant_type": 'password', "username": usuario, "password": passwordAsMd5 });
        return this.http.post(this.httpUtil.url(this.loginUrl), params, this.httpUtil.headers())
            .map(this.httpUtil.extrairDados)
            .catch(this.httpUtil.processarErros);
    }
    sair() {
        delete localStorage['token'];
    }
    logado() {
        return localStorage['token'];
    }
};
LoginService = __decorate([
    core_1.Injectable(), 
    __metadata('design:paramtypes', [http_1.Http, http_util_service_1.HttpUtilService])
], LoginService);
exports.LoginService = LoginService;
//# sourceMappingURL=login-service.js.map