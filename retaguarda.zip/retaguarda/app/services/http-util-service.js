"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const core_1 = require('@angular/core');
const http_1 = require('@angular/http');
const Observable_1 = require('rxjs/Observable');
let HttpUtilService = class HttpUtilService {
    constructor() {
        this.API_URL = 'http://172.18.164.6:9082/';
    }
    url(path) {
        return this.API_URL + path;
    }
    /*
    POST /cadu/oauth/token HTTP/1.1
    Host: apporbitall-hml:9082
    Content-Type: application/x-www-form-urlencoded
    systemName: siteOle
    environmentName: hml
    Authorization: Basic cmV0YWd1YXJkYTpvcmJpdGFsbA==
    Cache-Control: no-cache
    Postman-Token: 024ad716-7669-88f5-642f-9354fd049d89
     
    grant_type=password&username=50473108097&password=e10adc3949ba59abbe56e057f20f883e
    
    */
    headers() {
        let headersParams = { 'Content-Type': 'application/x-www-form-urlencoded',
            'Authorization': 'Basic cmV0YWd1YXJkYTpvcmJpdGFsbA==',
            'systemName': 'siteOle',
            'environmentName': 'hml',
            'productName': 'appOrbitallCard' };
        if (localStorage['token']) {
            headersParams['Authorization'] = localStorage['token'];
        }
        let headers = new http_1.Headers(headersParams);
        let options = new http_1.RequestOptions({ headers: headers });
        return options;
    }
    extrairDados(response) {
        let data = response.json();
        return data || {};
    }
    processarErros(erro) {
        return Observable_1.Observable.throw('Erro acessando servidor remoto.');
    }
};
HttpUtilService = __decorate([
    core_1.Injectable(), 
    __metadata('design:paramtypes', [])
], HttpUtilService);
exports.HttpUtilService = HttpUtilService;
//# sourceMappingURL=http-util-service.js.map