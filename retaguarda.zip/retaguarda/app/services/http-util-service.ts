import { Injectable } from '@angular/core';
import { Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class HttpUtilService {

	private API_URL: string = 'http://172.18.164.6:9082/';

	url(path: string) {
		return this.API_URL + path;
	}

/*
POST /cadu/oauth/token HTTP/1.1
Host: apporbitall-hml:9082
Content-Type: application/x-www-form-urlencoded
systemName: siteOle
environmentName: hml
Authorization: Basic cmV0YWd1YXJkYTpvcmJpdGFsbA==
Cache-Control: no-cache
Postman-Token: 024ad716-7669-88f5-642f-9354fd049d89
 
grant_type=password&username=50473108097&password=e10adc3949ba59abbe56e057f20f883e

*/

	headers() {
		let headersParams = 
			{ 'Content-Type' 	:	'application/x-www-form-urlencoded',
			  'Authorization'	:   'Basic cmV0YWd1YXJkYTpvcmJpdGFsbA==',
			  'systemName'		:   'siteOle',
			  'environmentName'	: 	'hml',
			  'productName'		:   'appOrbitallCard'}

		if (localStorage['token']) {
			headersParams['Authorization'] = localStorage['token'];
		}
		let headers = new Headers(headersParams);
    	let options = new RequestOptions({ headers: headers });
    	return options;
	}

	extrairDados(response: Response) {
    	let data = response.json();
    	return data || {};
  	}

  	processarErros(erro: any) {
	    return Observable.throw('Erro acessando servidor remoto.');
	}
}