import { Component } from '@angular/core';
import { Empresa } from '../.././models/empresa';
import { EmpresaService } from '../.././services/empresa-service';
import { OnInit } from '@angular/core';
import { Router, ActivatedRoute, ROUTER_DIRECTIVES } from '@angular/router'; 

@Component({
	selector: 'empresa-editar',
	templateUrl: 'app/views/empresas/editar.html',
	providers: [ EmpresaService ],
	directives: [ ROUTER_DIRECTIVES ]
})
export class EmpresaEditarComponent implements OnInit {

	private id: number;
	private empresa: Empresa;
	private msgErro: string;

	constructor(
		private route: ActivatedRoute, 
		private router: Router, 
		private empresaService: EmpresaService) {
	}

	ngOnInit() {
		this.id = +this.route.snapshot.params['id'];
		this.empresa = new Empresa();
		this.empresaService.buscarPorId(this.id)
			.subscribe(
                	empresa => this.empresa = empresa,
                	error => this.msgErro = error);
	}

	atualizar() {
		this.empresaService.atualizar(this.empresa)
			.subscribe(
                	empresa => this.router.navigate(['/empresa-listar']),
                	error => this.msgErro = error);
	}
}