import { Component } from '@angular/core';
import { Empresa } from '../.././models/empresa';
import { EmpresaService } from '../.././services/empresa-service';
import { OnInit } from '@angular/core';
import { ROUTER_DIRECTIVES, ActivatedRoute } from '@angular/router';

@Component({
	selector: 'empresa-visualizar',
	templateUrl: 'app/views/empresas/visualizar.html',
	providers: [ EmpresaService ],
	directives: [ ROUTER_DIRECTIVES ]
})
export class EmpresaVisualizarComponent implements OnInit {

	private id: number;
	private empresa: Empresa;
	private msgErro: string;

	constructor(
		private route: ActivatedRoute, 
		private empresaService: EmpresaService) {
	}

	ngOnInit() {
		this.id = +this.route.snapshot.params['id'];
		this.empresa = new Empresa();
		this.empresaService.buscarPorId(this.id)
			.subscribe(
                	empresa => this.empresa = empresa,
                	error => this.msgErro = error);
	}
}