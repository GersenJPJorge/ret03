import { Component } from '@angular/core';
import { Empresa } from '../.././models/empresa';
import { EmpresaService } from '../.././services/empresa-service';
import { OnInit } from '@angular/core';
import { Router, ROUTER_DIRECTIVES } from '@angular/router';

@Component({
	selector: 'empresa-cadastrar',
	templateUrl: 'app/views/empresas/cadastrar.html',
	providers: [ EmpresaService ],
	directives: [ ROUTER_DIRECTIVES ]
})
export class EmpresaCadastrarComponent implements OnInit {

	private empresa: Empresa;
	private msgErro:string;

	constructor(private router: Router, 
		private empresaService: EmpresaService) {
	}

	ngOnInit() {
		this.empresa = new Empresa();
	}

	cadastrar() {
		this.empresaService.cadastrar(this.empresa)
			.subscribe(
                	empresa => this.router.navigate(['/empresa-listar']),
                	error => this.msgErro = error);
		
	}
}