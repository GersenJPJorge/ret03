import { Component } from '@angular/core';
import { Empresa } from '../.././models/empresa';
import { EmpresaService } from '../.././services/empresa-service';
import { OnInit } from '@angular/core';
import { ROUTER_DIRECTIVES } from '@angular/router';
import { ModalUtilComponent } from '../utils/modal-util-component';

@Component({
	selector: 'empresa-listar',
	templateUrl: 'app/views/empresas/listar.html',
	providers: [ EmpresaService ],
	directives: [ ROUTER_DIRECTIVES, ModalUtilComponent ]
})
export class EmpresaListarComponent implements OnInit {

	private empresas: Empresa[];
	private idExcluir: number;
	private msgErro: string;

	constructor(private empresaService: EmpresaService) {
	} 

	listarTodos() {
		this.empresaService.listarTodos()
				.subscribe(
                	empresas => this.empresas = empresas,
                	error  => this.msgErro = error);
	}

	ngOnInit() {
		this.listarTodos();
	}

	excluir(id: number) {
 		this.idExcluir = id;
 	}

 	onExcluir() {
 		this.empresaService.excluir(this.idExcluir)
 			.subscribe(
                	data  => this.listarTodos(),
                	error => this.msgErro = error);
 		this.idExcluir = -1;
 	}
}