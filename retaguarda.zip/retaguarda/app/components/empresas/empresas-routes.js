"use strict";
const empresa_listar_component_1 = require('./empresa-listar-component');
const empresa_cadastrar_component_1 = require('./empresa-cadastrar-component');
const empresa_editar_component_1 = require('./empresa-editar-component');
const empresa_visualizar_component_1 = require('./empresa-visualizar-component');
const login_guard_1 = require('../../login-guard');
exports.EmpresasRoutes = [
    {
        path: 'empresa-listar',
        component: empresa_listar_component_1.EmpresaListarComponent,
        canActivate: [login_guard_1.LoginGuard]
    },
    {
        path: 'empresa-cadastrar',
        component: empresa_cadastrar_component_1.EmpresaCadastrarComponent,
        canActivate: [login_guard_1.LoginGuard]
    },
    {
        path: 'empresa-editar/:id',
        component: empresa_editar_component_1.EmpresaEditarComponent,
        canActivate: [login_guard_1.LoginGuard]
    },
    {
        path: 'empresa-visualizar/:id',
        component: empresa_visualizar_component_1.EmpresaVisualizarComponent,
        canActivate: [login_guard_1.LoginGuard]
    },
    {
        path: '',
        redirectTo: '/empresa-listar',
        terminal: true
    }
];
//# sourceMappingURL=empresas-routes.js.map