import { RouterConfig } from '@angular/router'; 
import { EmpresaListarComponent } from './empresa-listar-component';
import { EmpresaCadastrarComponent } from './empresa-cadastrar-component';
import { EmpresaEditarComponent } from './empresa-editar-component';
import { EmpresaVisualizarComponent } from './empresa-visualizar-component';
import { LoginGuard } from '../../login-guard';

export const EmpresasRoutes: RouterConfig = [
	{ 
		path: 'empresa-listar', 
		component: EmpresaListarComponent, 
		canActivate: [ LoginGuard ] 
	}, 
	{ 
		path: 'empresa-cadastrar', 
		component: EmpresaCadastrarComponent, 
		canActivate: [ LoginGuard ] 
	}, 
	{ 
		path: 'empresa-editar/:id', 
		component: EmpresaEditarComponent, 
		canActivate: [ LoginGuard ] 
	},
	{ 
		path: 'empresa-visualizar/:id', 
		component: EmpresaVisualizarComponent, 
		canActivate: [ LoginGuard ] 
	},
	{ 
		path: '', 
		redirectTo: '/empresa-listar', 
		terminal: true 
	}
];