"use strict";
const router_1 = require('@angular/router');
const empresas_routes_1 = require('./components/empresas/empresas-routes');
const login_routes_1 = require('./components/autenticacao/login-routes');
const login_routes_2 = require('./components/autenticacao/login-routes');
exports.routes = [
    ...empresas_routes_1.EmpresasRoutes,
    ...login_routes_1.LoginRoutes
];
exports.APP_ROUTER_PROVIDERS = [
    router_1.provideRouter(exports.routes),
    login_routes_2.AUTH_PROVIDERS
];
//# sourceMappingURL=app-routes.js.map